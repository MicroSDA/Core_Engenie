<?php
/**
 * Created by PhpStorm.
 * User: bansc
 * Date: 1/2/2018
 * Time: 5:56 PM
 */

require 'libs/Router.php';
require 'controllers/Controller.php';
require 'models/Model.php';
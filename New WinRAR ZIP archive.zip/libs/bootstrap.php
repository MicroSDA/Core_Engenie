<?php
/**
 * Created by PhpStorm.
 * User: bansc
 * Date: 1/2/2018
 * Time: 5:56 PM
 */


require_once 'plugins_search.php';
require_once 'libs/Router.php';
require_once 'controllers/Controller.php';
require_once 'models/Model.php';
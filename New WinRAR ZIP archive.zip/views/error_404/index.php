<body>

<div class="container">

<div class="jumbotron">
    <h1>
    <p> OPs ! (( ERROR 404 </p>
    </h1>

    <a href="/" class="btn btn-info">Home</a>
</div>
</div>
<!-- Bootstrap core JavaScript -->
</body>
</html>
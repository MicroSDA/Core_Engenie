<body>

<div class="container">

<div class="jumbotron">
    <h1>
    <p> OPs ! (( ERROR 404 </p>
    </h1>

    <a href="/" class="btn btn-info">Leave a Review</a>
</div>
</div>
<!-- Bootstrap core JavaScript -->
</body>
</html>
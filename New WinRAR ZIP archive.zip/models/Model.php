<?php
/**
 * User: Ro Kovalenko
 * Date: 12/30/2017
 * Time: 7:59 PM
 */

class Model
{

    protected $plugin_data;
    protected $model_name;

    public function __construct($plugin_data_income){

        $this->plugin_data = $plugin_data_income;


    }

}
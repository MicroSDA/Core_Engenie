<?php


class Controller
{

    protected $parameters = '';
    protected $models;
    protected $plugin_data;

    public function __construct() {


    }

}
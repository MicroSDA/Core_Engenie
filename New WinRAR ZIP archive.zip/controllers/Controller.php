<?php
/**
 * User: Ro Kovalenko
 * Date: 12/30/2017
 * Time: 1:19 PM
 */

class Controller
{

    protected $parameters = '';
    protected $models;

    public function __construct() {


    }

}